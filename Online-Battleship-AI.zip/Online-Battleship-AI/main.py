import tkinter as tk
from ui.game_view import run_game

if __name__ == "__main__":
    run_game()
